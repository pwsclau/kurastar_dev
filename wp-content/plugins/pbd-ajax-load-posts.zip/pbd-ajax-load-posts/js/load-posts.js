$(document).ready(function($) {

	/** IMPORTANT
	**  NOTE:: 'custom_page_class' value can be found on the HEADER.*/
		
		// Default functionality

			// The number of the next page to load (/page/x/).
			var pageNum = parseInt(pbd_alp.startPage) + 1;
		//	console.log(pbd_alp.startPage);
			
			// The maximum number of pages the current query can return.
			var max = parseInt(pbd_alp.maxPages);
			
			
			// The link of the next page of posts.
			var nextLink = pbd_alp.nextLink;

			/**
			 * Replace the traditional navigation with our own,
			 * but only if there is at least one page of new posts to load.
			 */

			if(pageNum <= max) {
				// Insert the "More Posts" link.
				$('.post-list-default')
					.append('<div class="pbd-alp-placeholder-'+ pageNum +'"></div>')
					.append('<p id="pbd-alp-load-posts"><a href="#">Load More Posts</a></p>');
					
				// Remove the traditional navigation.
				$('.navigation').remove();
			}
			
			
			/**
			 * Load new posts when the link is clicked.
			 */

			$('#pbd-alp-load-posts a').click(function() {
				
				// Are there more posts to load?
				if(pageNum <= max) {
				
					// Show that we're working.
					$(this).text('Loading posts...');
					
					$('.pbd-alp-placeholder-'+ pageNum).load(nextLink + ' .post',
						function() {
							// Update page number and nextLink.
							pageNum++;
							nextLink = nextLink.replace(/\/page\/[0-9]?/, '/page/'+ pageNum);
							
							// Add a new placeholder, for when user clicks again.
							$('#pbd-alp-load-posts')
								.before('<div class="pbd-alp-placeholder-'+ pageNum +'"></div>')
							
							// Update the button message.
							if(pageNum <= max) {
								$('#pbd-alp-load-posts a').text('Load More Posts');
							} else {
								$('#pbd-alp-load-posts a').text('No more posts to load.');
							}
						}
					);
				} else {
					$('#pbd-alp-load-posts a').append('.');
				}	
				
				return false;
			});
		



		//to work with load more publish tab


			// The number of the next page to load (/page/x/).
			var p_num = parseInt(publish_start) + 1;

			console.log(publish_start);
			
			
			// The maximum number of pages the current query can return.
			var p_max = parseInt(publish_max);
			
			
			// The link of the next page of posts.
			var p_next = publish_next;


			console.log(p_num +''+p_max+''+p_next);


			if(p_num <= p_max) {
				// Insert the "More Posts" link.
				$('.post-publish')
					.append('<div class="pbd-alp-placeholder-publish-'+ p_num +'"></div>')
					.append('<p id="pbd-alp-load-posts-publish2"><a href="#">Load More Posts</a></p>');
					
				// Remove the traditional navigation.
				$('.navigation').remove();
			}

			$('#pbd-alp-load-posts-publish a').click(function() {

				
				console.log('test'+p_num);
				
				console.log(p_num +''+p_max+''+p_next);

				// Are there more posts to load?
				if(p_num <= p_max) {
				
					// Show that we're working.
					$(this).text('Loading posts...');
					
					$('.pbd-alp-placeholder-publish-'+ p_num).load(p_next + ' .post-publish-list',
						function() {

							// Update page number and next link.
							p_num++;
							p_next = p_next.replace(/\/page\/[0-9]?/, '/page/'+ p_num);

							// Add a new placeholder, for when user clicks again.
							$('#pbd-alp-load-posts-publish')
								.before('<div class="pbd-alp-placeholder-publish-'+ p_num +'"></div>')
							
							// Update the button message.
							if(p_num <= p_max) {
								$('#pbd-alp-load-posts-publish a').text('Load More Posts');
							} else {
								$('#pbd-alp-load-posts-publish a').text('No more posts to load.');
							}
						}
					);
				} else {
					$('#pbd-alp-load-posts-publish a').append('.');
				}	
				
				return false;
			});
	

		//to work with load more favorite tab



			// The number of the next page to load (/page/x/).
			var f_num = parseInt(favorite_start) + 1;
			
			// The maximum number of pages the current query can return.
			var f_max = parseInt(favorite_max);
						
			// The link of the next page of posts.
			var f_next = favorite_next;


			if(f_num <= f_max) {
				// Insert the "More Posts" link.
				$('.post-favorite')
					.append('<div class="pbd-alp-placeholder-favorite-'+ f_num +'"></div>')
					.append('<p id="pbd-alp-load-posts-favorite"><a href="#">Load More Posts</a></p>');
					
				// Remove the traditional navigation.
				$('.navigation').remove();
			}

			$('#pbd-alp-load-posts-favorite a').click(function() {
				
				// Are there more posts to load?
				if(f_num <= f_max) {
				
					// Show that we're working.
					$(this).text('Loading posts...');
					
					$('.pbd-alp-placeholder-favorite-'+ f_num).load(f_next + ' .post-favorite-list',
						function() {
							// Update page number and next link.

							f_num++;
							f_next = f_next.replace(/\/page\/[0-9]?/, '/page/'+ f_num);
							
							// Add a new placeholder, for when user clicks again.
							$('#pbd-alp-load-posts-favorite')
								.before('<div class="pbd-alp-placeholder-favorite-'+ f_num +'"></div>')
							
							// Update the button message.
							if(f_num <= f_max) {
								$('#pbd-alp-load-posts-favorite a').text('Load More Posts');
							} else {
								$('#pbd-alp-load-posts-favorite a').text('No more posts to load.');
							}
						}
					);
				} else {
					$('#pbd-alp-load-posts-favorite a').append('.');
				}	
				
				return false;
			});
	

		//to work with load more draft tab

			// The number of the next page to load (/page/x/).
			var d_num = parseInt(draft_start) + 1;
			
			// The maximum number of pages the current query can return.
			var d_max = parseInt(draft_max);
						
			// The link of the next page of posts.
			var d_next = draft_next;			

			if(d_num <= d_max) {
				// Insert the "More Posts" link.
				$('.post-draft')
					.append('<div class="pbd-alp-placeholder-draft-'+ d_num +'"></div>')
					.append('<p id="pbd-alp-load-posts-draft"><a href="#">Load More Posts</a></p>');
					
				// Remove the traditional navigation.
				$('.navigation').remove();
			}

			$('#pbd-alp-load-posts-draft a').click(function() {
				
				console.log(d_num +''+d_max+''+d_next);
				// Are there more posts to load?
				if(d_num <= d_max) {
				
					// Show that we're working.
					$(this).text('Loading posts...');
					
					$('.pbd-alp-placeholder-draft-'+ d_num).load(d_next + ' .post-draft-list',
						function() {
							// Update page number and next link.
						
							d_num++;
							d_next = d_next.replace(/\/page\/[0-9]?/, '/page/'+ d_num);

							// Add a new placeholder, for when user clicks again.
							$('#pbd-alp-load-posts-draft')
								.before('<div class="pbd-alp-placeholder-draft-'+ d_num +'"></div>')
							
							// Update the button message.
							if(d_num <= d_max) {
								$('#pbd-alp-load-posts-draft a').text('Load More Posts');
							} else {
								$('#pbd-alp-load-posts-draft a').text('No more posts to load.');
							}
						}
					);
				} else {
					$('#pbd-alp-load-posts-draft a').append('.');
				}	
				
				return false;
			});
	
		
});